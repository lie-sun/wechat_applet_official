<?php
/**
 * gx_1模块微站定义
 *
 * @author minishilibo1
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Gx_1ModuleSite extends WeModuleSite {




}