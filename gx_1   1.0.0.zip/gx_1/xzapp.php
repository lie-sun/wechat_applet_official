<?php
/**
 * gx_1熊掌号接口定义
 *
 * @author minishilibo1
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Gx_1ModuleXzapp extends WeModuleXzapp {
	public function doPageTest(){
		global $_GPC, $_W;
		// 此处开发者自行处理
		include $this->template('test');
	}

}