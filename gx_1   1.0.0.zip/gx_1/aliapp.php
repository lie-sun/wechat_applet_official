<?php
/**
 * gx_1支付宝小程序接口定义
 *
 * @author minishilibo1
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Gx_1ModuleAliapp extends WeModuleAliapp {
	public function doPageTest(){
		global $_GPC, $_W;
		// 此处开发者自行处理
		include $this->template('test');
	}
}