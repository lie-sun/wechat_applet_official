<?php
/**
 * ca1_bb1wqe模块微站定义
 *
 * @author minishilibo1
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Ca1_bb1wqeModuleSite extends WeModuleSite {




}