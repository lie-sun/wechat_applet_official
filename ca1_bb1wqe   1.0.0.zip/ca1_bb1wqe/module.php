<?php
/**
 * ca1_bb1wqe模块定义
 *
 * @author minishilibo1
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Ca1_bb1wqeModule extends WeModule {



}