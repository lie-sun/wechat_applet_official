<?php
/**
 * ca1_bb1wqe模块APP接口定义
 *
 * @author minishilibo1
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Ca1_bb1wqeModulePhoneapp extends WeModulePhoneapp {
	public function doPageTest(){
		global $_GPC, $_W;
		$errno = 0;
		$message = '返回消息';
		$data = array();
		return $this->result($errno, $message, $data);
	}
	
	
}