var siteinfo = { "uniacid": "3", "acid": "3", "multiid": "0", "version": "1.0", "siteroot": "https://pro.we7.cc/app/index.php", "design_method": "3" }
module.exports = siteinfo